contacts = [
    {
        'first_name': 'Josh',
        'last_name': 'Medeski',
        'phone': 2810000000,
    },
    {
        'first_name': 'Josh',
        'last_name': 'Smith',
        'phone': 2810000001,
    },
    {
        'first_name': 'Ricky',
        'last_name': '',
        'phone': 7130000000
    },
]